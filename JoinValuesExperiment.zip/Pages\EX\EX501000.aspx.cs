using PX.Web.UI;
using System;

public partial class Page_EX501000 : PXPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}